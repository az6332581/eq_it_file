from django.http import StreamingHttpResponse
import pymysql
import numpy as np
import os
import sys
import tensorflow as tf
from distutils.version import StrictVersion
from collections import defaultdict
from io import StringIO
from matplotlib import pyplot as plt
from PIL import Image
from os.path import isfile, isdir, join
# This is needed since the notebook is stored in the object_detection folder.
sys.path.append("/home/user/models/research")
sys.path.append("/home/user/models/research/object_detection")
from object_detection.utils import ops as utils_ops
# This is needed to display the images.
from utils import label_map_util
from utils import visualization_utils as vis_util
from django.shortcuts import render
from django.http import JsonResponse
import time;
import datetime;

MODEL_NAME = '/home/user/train_dummies/new_mod'
PATH_TO_FROZEN_GRAPH = MODEL_NAME + '/frozen_inference_graph.pb'
PATH_TO_LABELS = os.path.join('/home/user/train_dummies/data', 'object-detection.pbtxt')
BASE = os.path.dirname(os.path.abspath(__file__))
category_index = label_map_util.create_category_index_from_labelmap(PATH_TO_LABELS, use_display_name=True)
# Create your views here.
IMAGE_SIZE = (12, 8)
detection_graph = tf.Graph()
with detection_graph.as_default():
    od_graph_def = tf.GraphDef()
    with tf.gfile.GFile(PATH_TO_FROZEN_GRAPH, 'rb') as fid:
        serialized_graph = fid.read()
        od_graph_def.ParseFromString(serialized_graph)
        tf.import_graph_def(od_graph_def, name='')
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
sess = tf.Session(graph=detection_graph,config=config)
ops = detection_graph.get_operations()  #tf.get_default_graph()
all_tensor_names = {output.name for op in ops for output in op.outputs}
tensor_dict = {}
for key in [
    'num_detections', 'detection_boxes', 'detection_scores',
    'detection_classes', 'detection_masks'
]:
    tensor_name = key + ':0'
    if tensor_name in all_tensor_names:
        tensor_dict[key] = detection_graph.get_tensor_by_name(
            tensor_name)
image_tensor = detection_graph.get_tensor_by_name('image_tensor:0')

def load_image_into_numpy_array(image):
    (im_width, im_height) = image.size
    return np.array(image.getdata()).reshape(
        (im_height, im_width, 3)).astype(np.uint8)
def upload_file(request):
    global image_tensor
    global tensor_dict
    global sess

    upload = request.FILES['file']
    output_path = os.path.join(BASE, 'output/' + upload.name)
    filePath = os.path.join(BASE, 'upload/' + upload.name)
    print("upload_name: ", upload.name)
    file = open(filePath, 'wb+')
    for chunk in upload.chunks():
        file.write(chunk)
    file.close()
    result = "ok"
    image = Image.open('/home/user/EQ_IT/image/upload/' + upload.name)
    #(x,y) = image.size
    #x_s = 640
    #y_s = y*x_s//x
    #y_s = 960
    #x_s = x*y_s//y
    
    #image = image.resize((x_s,y_s),Image.ANTIALIAS)################################################
    # the array based representation of the image will be used later in order to prepare the
    # result image with boxes and labels on it.
    image_np = load_image_into_numpy_array(image)
    # Expand dimensions since the model expects images to have shape: [1, None, None, 3]
    # Actual detection.
    # Run inference
    output_dict = sess.run(tensor_dict,
                           feed_dict={image_tensor: np.expand_dims(image_np, 0)})
    # all outputs are float32 numpy arrays, so convert types as appropriate
    output_dict['num_detections'] = int(output_dict['num_detections'][0])
    output_dict['detection_classes'] = output_dict[
        'detection_classes'][0].astype(np.uint8)
    output_dict['detection_boxes'] = output_dict['detection_boxes'][0]
    output_dict['detection_scores'] = output_dict['detection_scores'][0]
    # Visualization of the results of a detection.
    image_np= vis_util.visualize_boxes_and_labels_on_image_array(
        image_np,
        output_dict['detection_boxes'],
        output_dict['detection_classes'],
        output_dict['detection_scores'],
        category_index,
        use_normalized_coordinates=True,
        line_thickness=1)
    class_name = ''
    #class_score = 'none'
    #class_name2 = 'none'
    #class_score2 = 'none'
    all_num = ['none','none','none','none','none']
    all_score = ['none','none','none','none','none']
    for i in range(0, output_dict['num_detections']):
        score = output_dict['detection_scores'][i]
        #print(score)
        if score > 0.6:
           for j in range(0, output_dict['num_detections']):
             all_score[i] = score
             all_num[i] = str(category_index[output_dict['detection_classes'][i]]['name'])






    upload_score = ['none','none','none','none','']
    upload_ok = ['NO','NO','NO','NO','']
    no_item = ['']
    upload_num = ['Industrial helmet','vest','Industrial gloves','safety harness','']



    if all_score[0] == 'none':
          no_item[0]= 'NO'
          print(class_name)

    elif all_score[0] > 0.6:
           no_item[0]= 'YES'
           for num_count in range(0,5):
               if all_num[num_count] == 'Industrial helmet':
                  upload_score[0] = all_score[num_count]
                  upload_ok[0] = 'OK'
               if all_num[num_count] == 'vest':
                  upload_score[1] = all_score[num_count]
                  upload_ok[1] = 'OK'
               if all_num[num_count] == 'Industrial gloves':
                  upload_score[2] = all_score[num_count]
                  upload_ok[2] = 'OK'
               if all_num[num_count] == 'safety harness':
                  upload_score[3] = all_score[num_count]
                  upload_ok[3] = 'OK'


    #if all_score[0] < 0.6:
              #    upload_ok[0] = 'NO'
              #    upload_ok[1] = 'NO'
              #    upload_ok[2] = 'NO'
              #    upload_ok[3] = 'NO'
               #if upload_ok[0] == 'OK':
               #   upload_num[0] = 'Industrial helmet'
               #if upload_ok[1] == 'OK':
               #   upload_num[1] = 'vest'
               #if upload_ok[2] == 'OK':
               #   upload_num[2] = 'glass'
               #if upload_ok[3] == 'OK':
               #   upload_num[3] = 'Industrial gloves'
               #if upload_ok[4] == 'OK':
               #   upload_num[4] = 'safety harness'

           db = pymysql.connect("192.168.1.24","abc123","abc123","django_eq_it")
           cursor = db.cursor()
           # UPDATE #  sql = "UPDATE eq_it_data SET NAME = '黃阿阿展' WHERE ID = '0001'"
           #DELETE #sql = "DELETE FROM eq_it_data WHERE ID = 'imag'"
           today  = datetime.date.today()

           sql = "INSERT INTO eq_it_data(ID,Industrial_helmet, \
              Industrial_helmet_ok,vest,vest_ok,Industrial_gloves, \
              Industrial_gloves_ok,safety_harness,safety_harness_ok,sign_in,FILE_NAME) \
              VALUES ('%s','%s', '%s','%s', '%s','%s', '%s','%s', '%s', '%s', '%s') ON DUPLICATE KEY UPDATE Industrial_helmet = '%s',Industrial_helmet_ok = '%s', vest = '%s',vest_ok = '%s', Industrial_gloves ='%s', Industrial_gloves_ok = '%s', safety_harness = '%s',safety_harness_ok = '%s' , sign_in = '%s'" % \
              (upload.name,str(upload_score[0]), str(upload_ok[0]),str(upload_score[1]), str(upload_ok[1]),str(upload_score[2]), str(upload_ok[2]),str(upload_score[3]), str(upload_ok[3]),str(datetime.date.today()),upload.name,str(upload_score[0]), str(upload_ok[0]),str(upload_score[1]), str(upload_ok[1]),str(upload_score[2]), str(upload_ok[2]),str(upload_score[3]), str(upload_ok[3]),str(datetime.date.today()))

           

           cursor.execute(sql)
           db.commit()
           db.close()

    #if upload_ok[0] == 'OK':
     #     upload_num[0] = 'Industrial helmet1123'
    #elif upload_ok[1] == 'OK':
     #     upload_num[1] = 'vest123'
    #elif upload_ok[2] == 'OK':
     #     upload_num[2] = 'glass123'
    #elif upload_ok[3] == 'OK':
     #     upload_num[3] = 'Industrial gloves123'
    #elif upload_ok[4] == 'OK':
     #     upload_num[4] = 'safety harness123'



    #cursor = db.cursor()

    #cursor.execute("DROP TABLE IF EXISTS EQ_IT")

    #sql = """CREATE TABLE EQ_IT (
         #NAME  CHAR(20) NOT NULL,
         #Industrial_gloves  CHAR(20),
         #Industrial_gloves_ok CHAR(1),
	 #Industrial_helmet  CHAR(20),
         #Industrial_helmet_ok CHAR(1),
         #safety_harness  CHAR(20),
         #safety_harness_ok CHAR(1),
         #slippers  CHAR(20),
         #slippers_ok CHAR(1),
         #vest  CHAR(20),
         #vest_ok CHAR(1))"""

 
    #cursor.execute(sql)

    #db.close()

    id_name = upload.name

 
    plt.figure(figsize=IMAGE_SIZE)
    image_np = Image.fromarray(image_np)
    image_np = image_np.save('/home/user/EQ_IT/image/output/'+upload.name)
    return JsonResponse({
        'status':0,
        'result1' : str(all_num[0]) +':'+str(all_score[0]),
        'result2' : str(all_num[1])+ ':' + str(all_score[1]),
        'result3' : str(all_num[2]) +':'+str(all_score[2]),
        'result4' : str(all_num[3])+ ':' + str(all_score[3]),
        'result5' : str(all_num[4]) +':'+str(all_score[4]),
        'respond': {
            'result' : str(upload_num[0]) +':'+str(upload_ok[0]) +" , "+ str(upload_num[1]) +':'+str(upload_ok[1]) +" , "+str(upload_num[2]) +':'+str(upload_ok[2]) +" , " +str(upload_num[3]) +':'+str(upload_ok[3]) +" , "  + str(datetime.date.today()) +"簽到完成"  + " , " +'員工編號 = ' +str(id_name)[0:4] + " , " + 'item' + " = " + str(no_item[0]),

        'Industrial_helmet' : str(upload_ok[0]),
        'vest' : str(upload_ok[1]),
        'Industrial_gloves' : str(upload_ok[2]),
        'safety_harness' : str(upload_ok[3])

        }


    })
